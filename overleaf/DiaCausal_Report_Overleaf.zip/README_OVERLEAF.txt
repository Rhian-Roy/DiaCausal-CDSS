Overleaf: New Project -> Upload Project -> choose this zip. Main document: 0Synopsis.tex. Compiler: pdfLaTeX. Press Recompile.
Then Share -> turn on link sharing to give your team a link.
