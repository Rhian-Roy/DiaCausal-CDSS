DiaCausal IEEE conference paper (rough draft). Main file: main.tex. Compiler: pdfLaTeX (BibTeX runs automatically on Overleaf).
Change the college e-mail domain once, on the \newcommand{\maildomain} line near the top of main.tex.
All numbers come from the project repository (results/*.csv); all data are synthetic.
